package model;

public interface InteractionObserver {
	
	public void stateChanged(InteractionState state);

}
