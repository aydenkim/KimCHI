package recognition;

public enum Direction {

	loop, up, down, UpLine, DownLine, LeftLine, RightLine, line, circle;


}
